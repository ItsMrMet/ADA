package com.thomas.CRUDAnimales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudAnimalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
