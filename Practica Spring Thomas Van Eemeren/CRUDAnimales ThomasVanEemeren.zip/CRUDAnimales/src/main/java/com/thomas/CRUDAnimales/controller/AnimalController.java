package com.thomas.CRUDAnimales.controller;

import com.thomas.CRUDAnimales.model.Animal;
import com.thomas.CRUDAnimales.service.AnimalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/animales")
@Tag(name = "Animales API", description = "API para gestionar animales")
public class AnimalController {

    @Autowired
    private AnimalService animalService;

    @GetMapping
    @Operation(summary = "Obtener todos los animales")
    public List<Animal> findAll() {
        return animalService.findAll();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un animal por ID")
    public ResponseEntity<Animal> findById(@PathVariable Long id) {
        return animalService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Crear un nuevo animal")
    public ResponseEntity<Animal> save(@RequestBody Animal animal) {
        animal.setId(null); // Asegura que el ID sea nulo para que se genere automáticamente
        return ResponseEntity.ok(animalService.save(animal));
    }


    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un animal existente")
    public ResponseEntity<Animal> update(@PathVariable Long id, @RequestBody Animal animal) {
        if (animalService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        animal.setId(id);
        return ResponseEntity.ok(animalService.save(animal));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un animal por ID")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        if (animalService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        animalService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping
    @Operation(summary = "Eliminar todos los animales")
    public ResponseEntity<Void> deleteAll() {
        animalService.deleteAll();
        return ResponseEntity.noContent().build();
    }
}
