package com.thomas.CRUDAnimales.repository;

import com.thomas.CRUDAnimales.model.Animal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnimalRepository extends JpaRepository<Animal, Long> {
}