package com.thomas.CRUDAnimales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudAnimalesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudAnimalesApplication.class, args);
	}
}