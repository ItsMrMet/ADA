package com.thomas.CRUDAnimales.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;

@Entity
@Data
public class Animal {
    public enum TipoAnimal {
        VERTEBRADO, INVERTEBRADO
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre no puede estar vacío")
    private String nombre;

    @NotNull(message = "La edad no puede ser nula")
    @Positive(message = "La edad debe ser un número positivo")
    private Integer edad;

    @NotNull(message = "El tipo de animal no puede ser nulo")
    @Enumerated(EnumType.STRING)
    private TipoAnimal tipoAnimal;

    @NotBlank(message = "La especie no puede estar vacía")
    private String especie;
}
